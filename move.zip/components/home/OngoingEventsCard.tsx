// components/home/OngoingEventsCard.tsx - FIXED VERSION
import { supabase } from "@/lib/supabase/client";
import { router } from "expo-router";
import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Alert, Pressable, Text, View } from "react-native";

type EventRow = {
  event_id: string;
  name: string | null;
  short_code: string | null;
  energy: number;
  last_activity: string | null;
  status?: string; // Added status field
};

export default function OngoingEventsCard() {
  const [rows, setRows] = useState<EventRow[]>([]);
  const [loading, setLoading] = useState(false);

  async function load() {
    try {
      setLoading(true);
      
      // Fetch events from Supabase with status filter
      const { data: events, error } = await supabase
        .from('events')
        .select('*')
        .eq('status', 'ongoing') // Only get ongoing events
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;

      // Transform data to match expected format
      const transformedEvents: EventRow[] = (events || []).map(ev => ({
        event_id: ev.event_id,
        name: ev.name,
        short_code: ev.short_code,
        energy: 0, // Will be calculated from scores
        last_activity: ev.created_at,
        status: ev.status,
      }));

      // Get energy counts for each event
      for (const event of transformedEvents) {
        const { data: scores } = await supabase
          .from('scores')
          .select('energy')
          .eq('event_id', event.event_id);
        
        event.energy = scores?.reduce((sum, s) => sum + (s.energy || 0), 0) || 0;
      }

      setRows(transformedEvents);
    } catch (err) {
      console.error("OngoingEventsCard error:", err);
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { 
    load();
    
    // Refresh every 30 seconds
    const interval = setInterval(load, 30000);
    return () => clearInterval(interval);
  }, []);

  // Top 3 only for the home card
  const top3 = useMemo(() => rows.slice(0, 3), [rows]);

  async function handleJoinEvent(eventId: string) {
    try {
      // Check if event is still ongoing
      const { data: event, error } = await supabase
        .from('events')
        .select('status, name, short_code')
        .eq('event_id', eventId)
        .single();

      if (error) throw error;

      if (event?.status === 'ended') {
        // Redirect to leaderboard for ended events
        Alert.alert(
          'Event Concluded',
          'This event has ended. View the final results?',
          [
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'View Results', 
              onPress: () => router.push(`/(home)/events/leaderboard?eventId=${eventId}`)
            }
          ]
        );
      } else {
        // Normal join flow for ongoing events
        router.push(`/(home)/scan?eventId=${eventId}`);
      }
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to join event');
    }
  }

  return (
    <View style={{ 
      backgroundColor: "#07141c", 
      borderRadius: 16, 
      borderWidth: 1, 
      borderColor: "#0f2430", 
      padding: 16, 
      gap: 12 
    }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View>
          <Text style={{ color: "#e5eef5", fontSize: 16, fontWeight: "700" }}>
            On-Going Events
          </Text>
          <Text style={{ color: "#8aa3b3", fontSize: 12, marginTop: 2 }}>
            Active events right now
          </Text>
        </View>
        
        <Pressable onPress={load}>
          <Text style={{ color: "#4ECDC4", fontSize: 12 }}>Refresh</Text>
        </Pressable>
      </View>

      {loading && (
        <View style={{ alignItems: "center", paddingVertical: 24 }}>
          <ActivityIndicator color="#4ECDC4" />
        </View>
      )}

      {!loading && top3.length === 0 && (
        <View style={{ alignItems: 'center', paddingVertical: 30 }}>
          <Text style={{ color: "#7c93a3", fontSize: 14 }}>
            No active events right now
          </Text>
          <Text style={{ color: "#5a6a7a", fontSize: 12, marginTop: 5 }}>
            Check back later or create your own!
          </Text>
        </View>
      )}

      {!loading && top3.map((ev) => {
        const displayName = ev.name || ev.short_code || `Event ${ev.event_id.slice(0, 6)}`;
        const ago = ev.last_activity ? timeAgo(ev.last_activity) : "Just now";
        
        return (
          <Pressable
            key={ev.event_id}
            onPress={() => handleJoinEvent(ev.event_id)}
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: "#0a1823",
              borderRadius: 12,
              padding: 14,
              borderWidth: 1,
              borderColor: "#152230",
            }}
          >
            <View style={{ 
              width: 40, 
              height: 40, 
              borderRadius: 20, 
              backgroundColor: "#4ECDC4",
              opacity: 0.2,
              alignItems: "center",
              justifyContent: "center",
              marginRight: 12,
            }}>
              <Text style={{ fontSize: 18 }}>🏃</Text>
            </View>

            <View style={{ flex: 1 }}>
              <Text style={{ 
                color: "#ffffff", 
                fontSize: 14, 
                fontWeight: "600",
                marginBottom: 2,
              }}>
                {displayName}
              </Text>
              <View style={{ flexDirection: "row", gap: 12 }}>
                <Text style={{ color: "#6a8090", fontSize: 12 }}>
                  {ev.energy} GP
                </Text>
                <Text style={{ color: "#6a8090", fontSize: 12 }}>
                  {ago}
                </Text>
              </View>
            </View>

            <View style={{
              backgroundColor: "#10b981",
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderRadius: 8,
            }}>
              <Text style={{ color: "#000", fontSize: 12, fontWeight: "600" }}>
                Join
              </Text>
            </View>
          </Pressable>
        );
      })}

      {!loading && rows.length > 3 && (
        <Pressable
          onPress={() => router.push("/(home)/events")}
          style={{
            alignItems: "center",
            paddingTop: 8,
          }}
        >
          <Text style={{ color: "#4ECDC4", fontSize: 13 }}>
            View all {rows.length} events →
          </Text>
        </Pressable>
      )}
    </View>
  );
}

function timeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (seconds < 60) return "Just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}