import SearchParamsWrapper from "@/components/SearchParamsWrapper";
import LeaderboardClient from "./LeaderboardClient";

export default function LeaderboardPage() {
  return (
    <SearchParamsWrapper>
      <LeaderboardClient />
    </SearchParamsWrapper>
  );
}