export { supabase } from "./client";

